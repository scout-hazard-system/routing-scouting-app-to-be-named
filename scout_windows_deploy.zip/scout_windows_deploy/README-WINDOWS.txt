Scout deploy bundle from pop-os
================================
Contents:
  bin/           scout / scout-gui launchers (Linux; on Windows use WSL or reinstall)
  config/        .env.example, agents.yaml, tasks.yaml, arizona_phase.json, pyproject.toml
  ssh/           pop-os public key to authorize
  SETUP-WINDOWS.ps1  enable OpenSSH + install authorized_keys + copy configs

On Windows (Admin PowerShell):
  1. Unzip/copy this folder somewhere
  2. Right-click SETUP-WINDOWS.ps1 -> Run with PowerShell (Admin)
  3. Install Ollama for Windows + enable Tailscale SSH if desired
  4. git clone https://github.com/wendigoro/scout_crew.git
  5. Copy config files into the clone; cp .env.example .env and edit

After OpenSSH is on, from pop-os:
  ssh -i ~/.ssh/id_ed25519_popos <windows-user>@100.82.130.47
