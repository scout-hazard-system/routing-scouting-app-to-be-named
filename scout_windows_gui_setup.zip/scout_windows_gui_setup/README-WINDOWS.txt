Scout fresh setup (GUI + Hermes-hc + blackboard + nvm)
======================================================

1) Accept Taildrop files on gibdowsvista (Tailscale tray).
2) Unzip scout_windows_gui_setup.zip if needed.
3) Admin PowerShell:

   Set-ExecutionPolicy -Scope Process Bypass -Force
   .\INSTALL-WINDOWS.ps1

Installs:
- Ollama + llama3.1 + qwen3:8b
- scout-hermes-hc1.0.0 (100k, thinking, Project Director)
- scout-hermes-hc1.0.0-64k
- nvm-windows + Node LTS + npm
- OpenSSH Server (optional remote)

GUI (Linux/WSL recommended for full PySide6 Scout GUI):
  tabs at startup: Hermes | Crew | Chat | Blackboard | Pipeline | Terminal
  Hermes tab: integrated chat + "Launch classic Hermes GUI" (hermes desktop)
  Blackboard: server controls + live snapshot
  Pipeline: pipeline category + artifact tails

Verify:
  ollama list
  ollama run scout-hermes-hc1.0.0 "Status: AZ alpha? One sentence."
  node -v && npm -v
